//
//  MapPinModel.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//
import Foundation
import MapKit
import CoreLocation

class MapPin: NSObject, MKAnnotation {
    let title: String?
    let coordinate: CLLocationCoordinate2D
    var markedStatus = false
    init(title: String, coordinate: CLLocationCoordinate2D) {
        self.title = title
        self.coordinate = coordinate
    }
}
