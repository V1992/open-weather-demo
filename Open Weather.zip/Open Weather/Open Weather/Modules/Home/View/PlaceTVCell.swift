//
//  PlaceTVCell.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//

import UIKit

class PlaceTVCell: UITableViewCell {
    @IBOutlet private weak var bgView: UIView!{
        didSet{
            bgView.layer.cornerRadius = 5.0
        }
    }
    @IBOutlet private weak var bookmarkBtn: UIButton!
    @IBOutlet private weak var placeLbl: UILabel!
    var index = Int()

    var pressedBookMarkBtn : ((_ sender : UIButton,_ index : Int) -> ())? = nil
    @IBAction func bookmarkBtnPressed(_ sender: UIButton) {
        pressedBookMarkBtn?(sender,index)
    }
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    func configureCell(_ data : MapPin){
        if data.markedStatus{
            bookmarkBtn.setBackgroundImage(UIImage.init(named: "add_bmark"), for: .normal)
        }else{
            bookmarkBtn.setBackgroundImage(UIImage.init(named: "remove_bmark"), for: .normal)
        }
        placeLbl.text = data.title
    }
}
