//
//  PlacesVC+TableView.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//

import Foundation
import UIKit

extension PlacesVC : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cityVC: CityVC = CityVC.instantiate(appStoryboard: .main)
        cityVC.placeList = placeList[indexPath.row]
        self.navigationController?.pushViewController(cityVC,animated:true)
    }
}
extension PlacesVC : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return placeList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: String(describing: PlaceTVCell.self), for: indexPath) as? PlaceTVCell else { return PlaceTVCell() }
        cell.index = indexPath.row
        cell.configureCell(placeList[indexPath.row])
        cell.pressedBookMarkBtn = { [weak self] (markBtn,index) in
            guard let self = self else{return}
            if markBtn.currentBackgroundImage == UIImage.init(named: "add_bmark"){
                markBtn.setBackgroundImage(UIImage.init(named: "remove_bmark"), for: .normal)
                self.placeList[index].markedStatus = false
                let data = self.placeList[index]
                self.deleteFromTableView(data,index)
            }else{
                markBtn.setBackgroundImage(UIImage.init(named: "add_bmark"), for: .normal)
                self.placeList[index].markedStatus = true
                self.saveData(data: self.placeList[index], UserDBObj: self.openDatabse())
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        let data = placeList[indexPath.row]
        if editingStyle == .delete {
            if data.markedStatus{
                deleteFromTableView(data,indexPath.row)
            }else{
                placeList.remove(at: indexPath.row)
            }
        }
        tableView.reloadData()
    }
}
