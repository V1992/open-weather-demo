//
//  PlacesVC.swift
//  Weather ForeCast
//
//  Created by VARADA on 24/09/21.
//

import UIKit
import CoreData

final class PlacesVC: UIViewController {
    var placeList : [MapPin] = [MapPin]()
    @IBOutlet weak var tableView: UITableView!
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        context = appDelegate.persistentContainer.viewContext
        let notificationCenter = NotificationCenter.default
        notificationCenter.addObserver(self,
                                       selector: #selector(trackPlaces),
                                       name: .addNewPlace,
                                       object: nil)
        notificationCenter.addObserver(self,
                                       selector: #selector(reloadData),
                                       name: .deleteAllRecords,
                                       object: nil)
        fetchData()
    }
    @objc func trackPlaces(notfication: NSNotification){
        if let info = notfication.userInfo{
            if let list = info["MapPin"] as? MapPin, !self.placeList.contains(where: {$0.title == list.title}){
                self.placeList.append(list)
                self.tableView.reloadData()
            }
        }
    }
    @objc func reloadData(notfication: NSNotification){
        self.placeList.removeAll(where: {$0.markedStatus == true})
        dump(self.placeList)
        self.tableView.reloadData()
    }
    @objc override func rightBarButtonWithTextTapped() {
        let addPlaceVC: SearchPlacesVC = SearchPlacesVC.instantiate(appStoryboard: .main)
        self.navigationController?.pushViewController(addPlaceVC,animated:true)
    }
}

extension PlacesVC {
    // MARK: Methods to Open, Store and Fetch data
    func openDatabse() -> NSManagedObject{
        let entity = NSEntityDescription.entity(forEntityName: Entity.name, in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        return newUser
    }
    func fetchData(){
        if context != nil{
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: Entity.name)
            request.returnsObjectsAsFaults = false
            do {
                let result = try context.fetch(request)
                for data in result as! [NSManagedObject] {
                    let lat = data.value(forKey: "lat") as! Double
                    let lon = data.value(forKey: "lon") as! Double
                    let place = data.value(forKey: "place") as! String
                    let loc = MapPin.init(title: place, coordinate: CLLocationCoordinate2D.init(latitude: lat, longitude: lon))
                    loc.markedStatus = true
                    self.placeList.append(loc)
                }
            } catch {}
        }
        self.tableView.reloadData()
    }
    func saveData(data : MapPin, UserDBObj:NSManagedObject) {
        UserDBObj.setValue(data.coordinate.latitude, forKey: "lat")
        UserDBObj.setValue(data.coordinate.longitude, forKey: "lon")
        UserDBObj.setValue(data.title, forKey: "place")
        do {
            try context.save()
        } catch {}
        self.tableView.reloadData()
    }
    func deleteFromTableView(_ data : MapPin,_ index : Int){
        self.placeList.remove(at: index)
        self.delete(data: data)
        do {
            try context.save()
        } catch{}
        self.tableView.reloadData()
    }
    func delete(data : MapPin){
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: Entity.name)
        fetchRequest.predicate = NSPredicate(format: "place==%@", data.title!)
        do{
                let test = try context.fetch(fetchRequest)
                if !test.isEmpty{
                    let objectToDelete = test[0] as! NSManagedObject
                    context.delete(objectToDelete)
                    do{
                        try context.save()
                    }
                    catch{}
                }
               }
        catch{}
    }
}
