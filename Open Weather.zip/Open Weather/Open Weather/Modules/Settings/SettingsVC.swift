//
//  SettingsVC.swift
//  Weather ForeCast
//
//  Created by VARADA on 24/09/21.
//

import UIKit
import CoreData

class SettingsVC: UIViewController {
    @IBOutlet weak var segmentReset: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        segmentReset.selectedSegmentIndex = 0
    }
    @IBAction func selectBookMarkSegment(_ sender: Any) {
        switch segmentReset.selectedSegmentIndex {
        case 1:
            resetAllRecords()
        default:
            break
        }
    }
    func resetAllRecords(){
        let context = ( UIApplication.shared.delegate as! AppDelegate ).persistentContainer.viewContext
        let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: Entity.name)
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
        do{
                try context.execute(deleteRequest)
                try context.save()
                NotificationCenter.default.post(name: .deleteAllRecords, object: nil, userInfo: nil)
            }
        catch{}
    }    
}
