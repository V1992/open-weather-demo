//
//  HelpVC.swift
//  Weather ForeCast
//
//  Created by VARADA on 24/09/21.
//

import UIKit
import WebKit

final class HelpVC: UIViewController {
    @IBOutlet private weak var webView: WKWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        setWebView()
    }
    func setWebView(){
        let link = URL(string: Endpoint.helpUrl)!
        let request = URLRequest(url: link)
        webView.load(request)
    }
}
