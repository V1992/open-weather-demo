//
//  SearchPlacesVC.swift
//  Parking Slots
//
//  Created by VARADA on 21/09/21.
//

import UIKit
import MapKit

final class SearchPlacesVC: UIViewController {
    private var searchCompleter = MKLocalSearchCompleter()
    private var searchResults = [MKLocalSearchCompletion]()
    @IBOutlet private weak var searchResultsTableView: UITableView!
    var selectedPlace : (([String : Any]) -> ())? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Search Places"
        navigationItem.backButtonTitle = ""
        searchCompleter.delegate = self
    }
}

extension SearchPlacesVC: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchCompleter.queryFragment = searchText
    }
}

extension SearchPlacesVC: MKLocalSearchCompleterDelegate {
    func completerDidUpdateResults(_ completer: MKLocalSearchCompleter) {
        searchResults = completer.results
        searchResultsTableView.reloadData()
    }
}

extension SearchPlacesVC: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchResults.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let searchResult = searchResults[indexPath.row]
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.textLabel?.text = searchResult.title
        cell.detailTextLabel?.text = searchResult.subtitle
        return cell
    }
}

extension SearchPlacesVC: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let completion = searchResults[indexPath.row]
        let searchRequest = MKLocalSearch.Request(completion: completion)
        let search = MKLocalSearch(request: searchRequest)
        search.start { (response, error) in
            let coordinate = response?.mapItems[0].placemark.coordinate
            let addPlacesVC: AddPlaceVC = AddPlaceVC.instantiate(appStoryboard: .main)
            addPlacesVC.mapPin = MapPin.init(title: (response?.mapItems[0].placemark.name)!, coordinate: coordinate!)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.navigationController?.pushViewController(addPlacesVC,animated:true)
            }
        }
    }
}
