//
//  AddPlaceVC.swift
//  Weather ForeCast
//
//  Created by VARADA on 24/09/21.
//

import UIKit
import MapKit

final class AddPlaceVC: UIViewController {
    @IBOutlet weak var mapView: MKMapView!
    var mapPin : MapPin? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        self.rightBarButtonWithText(text: "Done")
        setPinUsingMKAnnotation()
    }
    @objc override func rightBarButtonWithTextTapped() {
        if let pin = mapPin{
            NotificationCenter.default.post(name: .addNewPlace, object: nil, userInfo: ["MapPin" : pin])
        }
        self.navigationController?.popToRootViewController(animated: false)
    }
    private func setPinUsingMKAnnotation() {
        let coordinateRegion = MKCoordinateRegion(center: (mapPin?.coordinate)!, latitudinalMeters: 800, longitudinalMeters: 800)
        mapView.setRegion(coordinateRegion, animated: true)
        mapView.addAnnotations([mapPin!])
    }
}
