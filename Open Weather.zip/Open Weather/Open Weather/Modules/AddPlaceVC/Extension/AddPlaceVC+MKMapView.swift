//
//  AddPlaceVC+MKMapView.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//

import Foundation
import MapKit
import CoreLocation

extension AddPlaceVC : MKMapViewDelegate{
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let Identifier = "Pin"
        let annotationView : MKAnnotationView = mapView.dequeueReusableAnnotationView(withIdentifier: Identifier) ?? MKAnnotationView(annotation: annotation, reuseIdentifier: Identifier)
        if annotation is MKUserLocation {
            return nil
        } else if annotation is MapPin {
            annotationView.canShowCallout = true
            annotationView.isDraggable = true
            annotationView.dragState = .dragging
            annotationView.image =  UIImage(imageLiteralResourceName: "marker")
            return annotationView
        } else {
            return nil
        }
    }
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, didChange newState: MKAnnotationView.DragState, fromOldState oldState: MKAnnotationView.DragState) {
        if newState == MKAnnotationView.DragState.ending {
            if let _ = view.annotation?.coordinate{
                view.canShowCallout = true
                if let annotation = view.annotation as? MapPin{
                    mapPin = annotation
                }
            }
        }
    }
}
