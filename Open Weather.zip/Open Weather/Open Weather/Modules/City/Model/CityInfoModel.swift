//
//  CityInfoModel.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//

import Foundation
// MARK: - City weather forecast Information
struct CityInfoModel: Codable {
    let coord: Coord?
    let weather: [Weather]?
    let base: String?
    let main: Main?
    let visibility: Int?
    let wind: Wind?
    let clouds: Clouds?
    let dt: Int?
    let sys: Sys?
    let timezone, id: Int?
    let name: String?
    let cod: Int?
}
// MARK: - Clouds related details of a particular city
struct Clouds: Codable {
    let all: Int?
}
// MARK: - Coordinates of city
struct Coord: Codable {
    let lon, lat: Double?
}
// MARK: -  Additional details of a city
struct Main: Codable {
    let temp, feelsLike, tempMin, tempMax: Double?
    let pressure, humidity, seaLevel, grndLevel: Int?
    
    enum CodingKeys: String, CodingKey {
        case temp
        case feelsLike = "feels_like"
        case tempMin = "temp_min"
        case tempMax = "temp_max"
        case pressure, humidity
        case seaLevel = "sea_level"
        case grndLevel = "grnd_level"
    }
}
// MARK: - sunrise and sunset of a city
struct Sys: Codable {
    let sunrise, sunset: Int?
}
// MARK: - Weather description of a city
struct Weather: Codable {
    let id: Int?
    let main, weatherDescription, icon: String?
    
    enum CodingKeys: String, CodingKey {
        case id, main
        case weatherDescription = "description"
        case icon
    }
}
// MARK: - Wind details of a city
struct Wind: Codable {
    let speed: Double?
}
