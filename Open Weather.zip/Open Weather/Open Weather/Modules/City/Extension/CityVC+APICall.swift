//
//  CityVC+APICall.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//

import Foundation

extension CityVC {
    func callCityInfoAPI(){
        let queryItems = [URLQueryItem(name: "lat", value: String(placeList?.coordinate.latitude ?? 0)
        ), URLQueryItem(name: "lon", value: String(placeList?.coordinate.longitude ?? 0)),URLQueryItem(name: "appid", value: Credentials.APIKEY)]
        var urlComps = URLComponents(string: Endpoint.baseUrl + Endpoint.cityInfoUrl)!
        urlComps.queryItems = queryItems
        let result = urlComps.url!
        let loader = self.loader()
        httpUtility.getApiData(requestUrl: result, resultType: CityInfoModel.self) { (status, error, response) in
            if status{
                if let jsonResponse = response {
                    self.cityData = jsonResponse
                    DispatchQueue.main.async {
                        self.bgView.isHidden = false
                        self.stopLoader(loader: loader)
                        self.setUIView()
                    }
                }
            }
        }
    }
}
