//
//  CityVC.swift
//  Weather ForeCast
//
//  Created by VARADA on 24/09/21.
//

import UIKit

final class CityVC: UIViewController {
    var placeList : MapPin? = nil
    var cityData : CityInfoModel? = nil
    @IBOutlet weak var bgView: UIView!
    @IBOutlet private weak var placeLbl: UILabel!
    @IBOutlet private weak var statusIconImage: UIImageView!
    @IBOutlet private weak var weatherStatusLbl: UILabel!
    @IBOutlet private weak var descirptionLbl: UILabel!
    @IBOutlet private weak var tempLbl: UILabel!
    @IBOutlet private weak var feelsLikeLbl: UILabel!
    @IBOutlet private weak var infoBgView: UIView!{
        didSet{
            infoBgView.layer.cornerRadius = 5.0
        }
    }
    @IBOutlet weak var tempView: UIView!{
        didSet{
            tempView.layer.cornerRadius = 5.0
        }
    }
    @IBOutlet private weak var windLbl: UILabel!
    @IBOutlet private weak var humidityLbl: UILabel!
    @IBOutlet private weak var pressureLbl: UILabel!
    @IBOutlet private weak var seaLevelLbl: UILabel!
    @IBOutlet private weak var groundLbl: UILabel!
    @IBOutlet private weak var visibilityLbl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Details"
        navigationItem.backButtonTitle = ""
        self.bgView.isHidden = true
        callCityInfoAPI()
    }
    func setUIView(){
        self.placeLbl.text = self.placeList?.title
        if let weather = self.cityData?.weather, !weather.isEmpty{
            let list = weather[0]
            self.weatherStatusLbl.text = list.weatherDescription
            self.descirptionLbl.text = list.main
        }
        self.tempLbl.text = "\(self.cityData?.main?.temp ?? 0)" + "℉"
        self.feelsLikeLbl.text = "Feels like \(self.cityData?.main?.feelsLike ?? 0)" + "℉"
        self.windLbl.text = "\(self.cityData?.wind?.speed ?? 0)" + "mph W"
        self.humidityLbl.text = "\(self.cityData?.main?.humidity ?? 0)" + "%"
        self.pressureLbl.text = "\(self.cityData?.main?.pressure ?? 0)" + "inHg"
        self.seaLevelLbl.text = "\(self.cityData?.main?.pressure ?? 0)" + "ft"
        self.groundLbl.text = "\(self.cityData?.main?.grndLevel ?? 0)" + "ft"
        self.visibilityLbl.text = "\(self.cityData?.visibility ?? 0)" + "mi"
    }
}
