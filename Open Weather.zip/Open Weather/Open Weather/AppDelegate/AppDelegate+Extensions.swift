//
//  AppDelegate+Extensions.swift
//  Weather ForeCast
//
//  Created by VARADA on 24/09/21.
//

import Foundation
import UIKit

extension AppDelegate {
    func redirectToHomeVC(){
        let navigationController = UINavigationController(rootViewController: configureTabView())
        navigationController.setNavigationBarHidden(true, animated: false)
        self.window?.rootViewController = navigationController
        self.window?.backgroundColor = .clear
    }
    private  func configureTabView() -> UITabBarController{
        let objHome = setUpViewController(tabTitle: "Home", headTitle: "Places", viewcontroller: setVC("PlacesVC"))
        let objSetting = setUpViewController(tabTitle:"Settings", headTitle: "Settings", viewcontroller: setVC("SettingsVC"))
        let objHelp = setUpViewController(tabTitle:"Help", headTitle: "Help"  , viewcontroller: setVC("HelpVC"))
        objHome.rightBarButtonWithText(text: "ADD")
        let controllers = [objHome, objSetting, objHelp]
        tabBarControllers.viewControllers = controllers.map { UINavigationController(rootViewController: $0)}
        tabBarControllers.tabBar.isTranslucent = false
        tabBarControllers.tabBar.unselectedItemTintColor = .lightGray
        tabBarControllers.navigationController?.setNavigationBarHidden(true, animated: false)
        tabBarControllers.selectedIndex = 0
        return tabBarControllers
    }
    private func setUpViewController(tabTitle: String,headTitle: String, viewcontroller : UIViewController) -> UIViewController {
        viewcontroller.tabBarItem.title = tabTitle
        viewcontroller.title = headTitle
        viewcontroller.navigationItem.backButtonTitle = ""
        return viewcontroller
    }
    private func setVC(_ identifier : String) -> UIViewController{
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        return storyboard.instantiateViewController(withIdentifier: identifier)
    }
}
