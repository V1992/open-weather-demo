//
//  UIViewController+Extensions.swift
//  Parking Slots
//
//  Created by VARADA on 21/09/21.
//

import Foundation
import UIKit

enum AppStoryboard: String {
    case main = "Main"
}

extension UIViewController{
    var httpUtility : HttpUtility{
        return HttpUtility()
    }
    func loader() -> UIAlertController {
        let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
        let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
        loadingIndicator.hidesWhenStopped = true
        loadingIndicator.startAnimating()
        alert.view.addSubview(loadingIndicator)
        
        appDelegate.window?.rootViewController?.present(alert, animated: true, completion: nil)
        return alert
    }
    func stopLoader(loader : UIAlertController) {
        DispatchQueue.main.async {
            loader.dismiss(animated: true, completion: nil)
        }
    }
    func showPopUpOnWindow(view :  UIView){
        view.frame = UIScreen.main.bounds
        view.backgroundColor = UIColor.black.withAlphaComponent(0.4)
        view.alpha = 0.0
        
        if let topController = appDelegate.window?.rootViewController {
            topController.view.addSubview(view)
        }
        view.transform = CGAffineTransform(translationX: 0, y: 0)
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .curveEaseOut,
                       animations: {
                        view.transform = CGAffineTransform(translationX: 1.0, y: 1.0)
                        view.alpha = 1.0
                       },
                       completion: { _ in
                       })
    }
    func hidePopUpOnWindow(view :  UIView){
        view.removeFromSuperview()
    }
    class func instantiate<T: UIViewController>(appStoryboard: AppStoryboard) -> T {
        
        let storyboard = UIStoryboard(name: appStoryboard.rawValue, bundle: nil)
        let identifier = String(describing: self)
        return storyboard.instantiateViewController(withIdentifier: identifier) as! T
    }
}

// MARK:- Extension For :- Notification.Name
extension Notification.Name {
    static let addNewPlace   = Notification.Name("addNewPlace")
    static let deleteAllRecords   = Notification.Name("deleteAllRecords")
}
