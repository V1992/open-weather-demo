//
//  UIViewController+NavigationItems.swift
//
//  Created by VARADA on 24/09/21.
//  Copyright © 2018 user. All rights reserved.
//

import UIKit

extension UIViewController {
    var appDelegate:AppDelegate {
        return UIApplication.shared.delegate as! AppDelegate
    }
    var uiApplication : UIApplication {
        return UIApplication.shared
    }
    func rightBarButtonWithText(text : String) {
        let cancelButton = UIBarButtonItem(title: text, style: UIBarButtonItem.Style.plain, target: self, action: #selector(self.rightBarButtonWithTextTapped))
        navigationItem.rightBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem?.tintColor = UIColor.black
    }
    @objc func rightBarButtonWithTextTapped() {
    }
}
