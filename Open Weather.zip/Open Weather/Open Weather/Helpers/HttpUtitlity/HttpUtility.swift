//
//  HttpUtility.swift
//  ImgSur
//
//  Created by VARADA on 25/05/21.
//

import UIKit

struct HttpUtility{
    func getApiData<T:Decodable>(requestUrl: URL, resultType: T.Type, completionHandler:@escaping(_ status : Bool,_ errorDesc : String,_ result: T?)-> Void){
        var urlRequest = URLRequest(url: requestUrl)
        urlRequest.httpMethod = "GET"
        URLSession.shared.dataTask(with: urlRequest) { (responseData, httpUrlResponse, error) in
            if(error == nil && responseData != nil && responseData?.count != 0)
            {
                //parse the responseData here
                let decoder = JSONDecoder()
                do {
                    let result = try decoder.decode(T.self, from: responseData!)
                    _=completionHandler(true, "",result)
                }catch let error{
                    _=completionHandler(false, (error.localizedDescription),nil)
                }
            }
        }.resume()
    }
}

