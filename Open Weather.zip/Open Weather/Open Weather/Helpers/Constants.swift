//
//  Constants.swift
//  Open Weather
//
//  Created by VARADA on 24/09/21.
//

import Foundation

struct Endpoint{
    static let baseUrl = "http://api.openweathermap.org"
    static let cityInfoUrl = "/data/2.5/weather?"
    static let helpUrl = "https://openweathermap.org/api/guide"
}
struct Credentials{
    static let APIKEY = "fae7190d7e6433ec3a45285ffcf55c86"
}
struct Entity{
    static let name = "Open_Weather"
}

