//
//  Open_WeatherTests.swift
//  Open WeatherTests
//
//  Created by VARADA on 25/09/21.
//
import UIKit
import XCTest
import MapKit
@testable import Open_Weather

class Open_WeatherTests: XCTestCase {
    var addPlaceObjTest : AddPlaceVC!
    override func setUp() {
        super.setUp()
        let storyboard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        addPlaceObjTest = storyboard.instantiateViewController(withIdentifier: "AddPlaceVC") as? AddPlaceVC
        if(addPlaceObjTest != nil) {
            addPlaceObjTest.loadView()
            addPlaceObjTest.viewDidLoad()
        }
    }
    func testViewControllerIsComposedOfMapView() {
        XCTAssertNotNil(self.addPlaceObjTest.mapView, "ViewController under test is not composed of a MKMapView")
    }
    func testControllerConformsToMKMapViewDelegate() {
        XCTAssert(addPlaceObjTest.responds(to: #selector(MKMapViewDelegate.mapView(_:viewFor:))))
    }
    func testMapViewDelegateIsSet() {
        XCTAssertNotNil(self.addPlaceObjTest.mapView.delegate)
    }
    func testControllerImplementsMKMapViewDelegateMethods() {
        XCTAssert(self.addPlaceObjTest.mapView.responds(to: #selector(MKMapViewDelegate.mapView(_:viewFor:))), "ViewController under test does not implement mapView:viewForAnnotation")
    }
    func testMapInitialization() {
        XCTAssert(addPlaceObjTest.mapView.mapType == MKMapType.standard);
    }
    func testControllerAddsAnnotationsToMapView() {
        let annotationsOnMap = self.addPlaceObjTest.mapView.annotations
        XCTAssertGreaterThan(annotationsOnMap.count, 0)
    }
    func testControllerCanAddPlaceAnnotationToMapView() {
        let coordinate = CLLocationCoordinate2DMake(40.703490, -73.987770)
        let annotation = MapPin(title: "BeerMenus HQ", coordinate: coordinate)
        let mapHasSchoolAnno = self.hasTargetAnnotation(annotationClass: annotation)
        XCTAssertTrue(mapHasSchoolAnno)
    }
    func hasTargetAnnotation(annotationClass: MKAnnotation) -> Bool {
        let mapAnnotations = self.addPlaceObjTest.mapView.annotations
        var hasTargetAnnotation = false
        for anno in mapAnnotations {
            if (anno is MapPin) {
                hasTargetAnnotation = true
            }
        }
        return hasTargetAnnotation
    }
}
